package com.neuedu.yyzxproject.service;

import com.neuedu.yyzxproject.pojo.Bed;

import java.util.List;

public interface BedService {
    public List<Bed> queryKxcwByRoomNo(String roomNo);
}
