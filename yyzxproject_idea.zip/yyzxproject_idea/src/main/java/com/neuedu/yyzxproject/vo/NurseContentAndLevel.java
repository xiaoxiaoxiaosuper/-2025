package com.neuedu.yyzxproject.vo;

import com.neuedu.yyzxproject.pojo.Nursecontent;
import lombok.Data;

import java.util.List;

@Data
public class NurseContentAndLevel {
    //-:护理级别对应的护理项目
    private List<Nursecontent> nursecontentList;
    private Integer nurselevel;
}
