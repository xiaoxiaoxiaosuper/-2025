package com.neuedu.yyzxproject.service.impl;

import com.neuedu.yyzxproject.mapper.UserMapper;
import com.neuedu.yyzxproject.pojo.Menu;
import com.neuedu.yyzxproject.pojo.User;
import com.neuedu.yyzxproject.service.UserService;
import com.neuedu.yyzxproject.utils.ResultVo;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserMapper userMapper;

    @Override
    public ResultVo login(String username, String password) {
        User user = new User();
        user.setUsername(username);
        user.setPassword(password);

        // 1.查看当前的用户是否存在
        User loginUser = userMapper.login(user);

        // 用户登录成功
        if (loginUser != null) {
            // 2.查看当前用户所能查看的功能菜单（登录成功了就可以查询相应的菜单了）
            // 2.1 通过用户的角色，查看对应的菜单（菜单和角色挂钩，不同角色的菜单不同）
            int roleId = loginUser.getRoleId(); // 获取角色的ID

            // -:查询一级菜单
            List<Menu> menuList = userMapper.getMenusByRole(roleId);

            // -：通过一级菜单获取二级菜单
            for (Menu menu : menuList) { // 遍历每一个一级菜单，
                List<Menu> menus = userMapper.getMenusByParentId(menu.getId());
                menu.setChildren(menus); // 又当前菜单查询到的菜单都是当前菜单的子菜单
            }

            loginUser.setMenuList(menuList);

            // 3.登录成功之后，生成一个口令：Token
            HashMap<String, Object> map = new HashMap<>();

            // 如果登录验证成功，则需要生成令牌token（token就是按照特定规则生成的字符串）
            JwtBuilder builder = Jwts.builder();

            String token = builder.setSubject(username) // 主题，就是token中携带的数据
                    .setIssuedAt(new Date()) // 设置token的生成时间
                    .setId(loginUser.getId().toString()) // 设置用户id为token id
                    .setClaims(map) // map中可以存放用户的角色权限信息
                    .setExpiration(new Date(System.currentTimeMillis() + 24 * 60 * 60 * 1000)) // 设置过期时间
                    .signWith(SignatureAlgorithm.HS256, "neuedu123") // 设置加密方式和加密密码
                    .compact();

            return ResultVo.ok(loginUser, token);
        } else { // 用户登录失败
            return ResultVo.fail("登录失败");
        }
    }
}
