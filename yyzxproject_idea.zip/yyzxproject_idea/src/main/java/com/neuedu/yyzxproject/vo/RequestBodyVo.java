package com.neuedu.yyzxproject.vo;

import com.neuedu.yyzxproject.pojo.*;
import lombok.Data;

@Data
public class RequestBodyVo {
    private PageInfoVo pageInfoVo;
    private BedDetailsVo bedDetailsVo;
    private Customer customer;
    private User user;
    private Nurselevel nurselevel;
    private PurchasedNursingServices purchasedNursingServices;
    private Nursecontent nursecontent;
    private FoodManage foodManage;
}
