package com.neuedu.yyzxproject.vo;

import com.neuedu.yyzxproject.pojo.Customer;
import lombok.Data;

import java.util.Date;

@Data
public class CustomerNursingRecords extends Customer {
    private String levelName;
}
