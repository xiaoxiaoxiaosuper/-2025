package com.neuedu.yyzxproject.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.neuedu.yyzxproject.mapper.OutWardMapper;
import com.neuedu.yyzxproject.pojo.BackDown;
import com.neuedu.yyzxproject.pojo.OutWard;
import com.neuedu.yyzxproject.service.OutWardService;
import com.neuedu.yyzxproject.vo.PageInfoVo;
import com.neuedu.yyzxproject.vo.PageResponseVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OutWardServiceImpl implements OutWardService {
    @Autowired
    private OutWardMapper outWardMapper;
    private <T> PageResponseVo<T> getPageResponse(List<T> list) {
        PageInfo<T> pageInfo = new PageInfo<>(list);
        long total = pageInfo.getTotal();
        int pageSize = pageInfo.getPageSize();
        int currentPage = pageInfo.getPageNum();
        int pages = pageInfo.getPages();
        List<T> dataList = pageInfo.getList();

        PageResponseVo<T> pageResponseVo = new PageResponseVo<>();
        pageResponseVo.setData(dataList);
        pageResponseVo.setCurrentPage(currentPage);
        pageResponseVo.setPageSize(pageSize);
        pageResponseVo.setTotal(total);
        pageResponseVo.setPageNum(pages);
        return pageResponseVo;
    }
    @Override
    public PageResponseVo<OutWard> queryAllOutwardInfo(PageInfoVo pageInfoVo) {
        PageHelper.startPage(pageInfoVo.getCurrentPage(),pageInfoVo.getPageSize());
        List<OutWard> outWards = outWardMapper.queryAllOutwardInfo();
        return getPageResponse(outWards);
    }

    @Override
    public int approval(OutWard outWard) {
        return outWardMapper.approval(outWard);
    }
}
