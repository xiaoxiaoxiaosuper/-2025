package com.neuedu.yyzxproject.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.neuedu.yyzxproject.mapper.BedDetailsMapper;
import com.neuedu.yyzxproject.pojo.BedDetails;
import com.neuedu.yyzxproject.service.BedDetailsService;
import com.neuedu.yyzxproject.vo.BedDetailsVo;
import com.neuedu.yyzxproject.vo.PageInfoVo;
import com.neuedu.yyzxproject.vo.PageResponseVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class BedDetailsServiceImpl implements BedDetailsService {

    @Autowired
    private BedDetailsMapper bedDetailsMapper;

    @Override
    public PageResponseVo<BedDetailsVo> queryBedInfo(PageInfoVo pageInfoVo, BedDetailsVo bedDetailsVo) {
        //-:配置分页信息(当前页码、每页显示的条数)
        PageHelper.startPage(pageInfoVo.getCurrentPage(), pageInfoVo.getPageSize());
        //-:查询到所有的数据
        List<BedDetailsVo> bedDetailsVos = bedDetailsMapper.queryBedInfo(bedDetailsVo);
        //-:获取对应页码中的数据
        PageInfo<BedDetailsVo> pageInfo = new PageInfo<>(bedDetailsVos);
        List<BedDetailsVo> list = pageInfo.getList();
        int currentPage = pageInfo.getPageNum();
        int pages = pageInfo.getPages();
        int pageSize = pageInfo.getPageSize();
        long total = pageInfo.getTotal();
        /**
         * 获取数据之后，返回当前页对应的内容
         */
        PageResponseVo<BedDetailsVo> pageResponseVo = new PageResponseVo<>();
        pageResponseVo.setPageNum(pages);
        pageResponseVo.setPageSize(pageSize);
        pageResponseVo.setCurrentPage(currentPage);
        pageResponseVo.setTotal(total);
        pageResponseVo.setData(list);
        return pageResponseVo;
    }

    @Override
    public int exchangeBedInfo(BedDetails bedDetails) {
        // 1. 将 bedDetails 中的 customerId 对应的数据的 is_deleted 设置为 1
        bedDetailsMapper.updateIsDeleted(bedDetails.getCustomerId());

        // 2. 将 bed 表中 bedId 对应的数据的 bed_status 设置为 1
        bedDetailsMapper.updateBedStatus(bedDetails.getBedId());
        bedDetailsMapper.updateOldBedId(bedDetails.getOldBedId());

        // 3. 查询 bed 表中 bedId 对应的 bed_no
        String bedNo = bedDetailsMapper.selectBedNoById(bedDetails.getBedId());

        // 4. 拼接 bed_details = "606#" + bed_no
        String newBedDetails = "606#" + bedNo;

        // 6. 插入数据到 beddetails 表
        bedDetails.setBedDetails(newBedDetails);
        return bedDetailsMapper.insertBedDetails(bedDetails);
    }

    @Override
    public int reviseBedInfo(BedDetails bedDetails) {
        return bedDetailsMapper.reviseBedInfo(bedDetails);
    }
}
