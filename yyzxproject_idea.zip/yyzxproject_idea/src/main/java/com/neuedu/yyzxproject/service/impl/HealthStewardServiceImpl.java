package com.neuedu.yyzxproject.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.neuedu.yyzxproject.mapper.HealthStewardMapper;
import com.neuedu.yyzxproject.pojo.Customer;
import com.neuedu.yyzxproject.pojo.User;
import com.neuedu.yyzxproject.service.HealthStewardService;
import com.neuedu.yyzxproject.vo.CustomerNursingRecords;
import com.neuedu.yyzxproject.vo.PageInfoVo;
import com.neuedu.yyzxproject.vo.PageResponseVo;
import com.neuedu.yyzxproject.vo.RequestBodyVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HealthStewardServiceImpl implements HealthStewardService {
    @Autowired
    private HealthStewardMapper healthStewardMapper;

    private <T> PageResponseVo<T> getPageResponse(List<T> list) {
        PageInfo<T> pageInfo = new PageInfo<>(list);
        long total = pageInfo.getTotal();
        int pageSize = pageInfo.getPageSize();
        int currentPage = pageInfo.getPageNum();
        int pages = pageInfo.getPages();
        List<T> dataList = pageInfo.getList();

        PageResponseVo<T> pageResponseVo = new PageResponseVo<>();
        pageResponseVo.setData(dataList);
        pageResponseVo.setCurrentPage(currentPage);
        pageResponseVo.setPageSize(pageSize);
        pageResponseVo.setTotal(total);
        pageResponseVo.setPageNum(pages);
        return pageResponseVo;
    }

    @Override
    public PageResponseVo<User> queryHealthSteward(PageInfoVo pageInfoVo, User user) {
        PageHelper.startPage(pageInfoVo.getCurrentPage(), pageInfoVo.getPageSize());
        List<User> users = healthStewardMapper.queryHealthSteward(user);
        return getPageResponse(users);
    }

    @Override
    public PageResponseVo<Customer> queryCustomerWithoutSteward(PageInfoVo pageInfoVo, Customer customer) {
        PageHelper.startPage(pageInfoVo.getCurrentPage(), pageInfoVo.getPageSize());
        List<Customer> customers = healthStewardMapper.queryCustomerWithoutSteward(customer);
        return getPageResponse(customers);
    }

    @Override
    public PageResponseVo<CustomerNursingRecords> queryServingCustomerById(PageInfoVo pageInfoVo, User user){
        PageHelper.startPage(pageInfoVo.getCurrentPage(), pageInfoVo.getPageSize());
        List<CustomerNursingRecords> customers = healthStewardMapper.queryServingCustomerById(user);
        return getPageResponse(customers);
    }

    @Override
    public int deleteServingCustomer(Integer id){
        int num = healthStewardMapper.deleteServingCustomer(id);
        return num;
    }
}