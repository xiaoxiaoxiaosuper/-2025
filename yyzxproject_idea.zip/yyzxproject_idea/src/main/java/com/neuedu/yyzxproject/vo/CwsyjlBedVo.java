package com.neuedu.yyzxproject.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

@Data
public class CwsyjlBedVo {
    private Integer ordinal;    // 序号
    private String nickname;    // 用户昵称
    //private Integer sex;        // 性别（0女 1男）
    private String sex;
    private String bedDetails;  // 床位详情
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date startDate;     // 入住日期
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date endDate;       // 退房日期
}
