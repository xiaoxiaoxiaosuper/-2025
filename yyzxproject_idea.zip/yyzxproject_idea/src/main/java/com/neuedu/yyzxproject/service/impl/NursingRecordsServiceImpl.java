package com.neuedu.yyzxproject.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.neuedu.yyzxproject.mapper.NursingRecordsMapper;
import com.neuedu.yyzxproject.pojo.Customer;
import com.neuedu.yyzxproject.pojo.NurseRecord;
import com.neuedu.yyzxproject.service.NursingRecordsService;
import com.neuedu.yyzxproject.vo.CustomerNursingRecords;
import com.neuedu.yyzxproject.vo.PageInfoVo;
import com.neuedu.yyzxproject.vo.PageResponseVo;
import com.neuedu.yyzxproject.vo.PurchasedNursingServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NursingRecordsServiceImpl implements NursingRecordsService {
    @Autowired
    private NursingRecordsMapper nursingrecordsMapper;

    @Override
    public PageResponseVo<CustomerNursingRecords> queryCustomerInfo(PageInfoVo pageInfoVo, Customer customer){
        PageHelper.startPage(pageInfoVo.getCurrentPage(), pageInfoVo.getPageSize());
        List<CustomerNursingRecords> customers = nursingrecordsMapper.queryCustomerInfo(customer);
        return getPageResponse(customers);
    }

    @Override
    public PageResponseVo<NurseRecord> queryNursingRecords(PageInfoVo pageInfoVo, Customer customer) {
        PageHelper.startPage(pageInfoVo.getCurrentPage(), pageInfoVo.getPageSize());
        List<NurseRecord> customerNursingRecords = nursingrecordsMapper.queryNursingRecords(customer);
        return getPageResponse(customerNursingRecords);
    }

    @Override
    public int deleteNursingRecordsById(Integer nursingRecordsId) {
        int num = nursingrecordsMapper.deleteNursingRecordsById(nursingRecordsId);
        return num;
    }

    private <T> PageResponseVo<T> getPageResponse(List<T> list) {
        PageInfo<T> pageInfo = new PageInfo<>(list);
        long total = pageInfo.getTotal();
        int pageSize = pageInfo.getPageSize();
        int currentPage = pageInfo.getPageNum();
        int pages = pageInfo.getPages();
        List<T> dataList = pageInfo.getList();

        PageResponseVo<T> pageResponseVo = new PageResponseVo<>();
        pageResponseVo.setData(dataList);
        pageResponseVo.setCurrentPage(currentPage);
        pageResponseVo.setPageSize(pageSize);
        pageResponseVo.setTotal(total);
        pageResponseVo.setPageNum(pages);
        return pageResponseVo;
    }
}
