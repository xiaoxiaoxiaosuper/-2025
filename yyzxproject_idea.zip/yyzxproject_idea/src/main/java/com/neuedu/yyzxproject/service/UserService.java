package com.neuedu.yyzxproject.service;

import com.neuedu.yyzxproject.utils.ResultVo;

public interface UserService {
    public ResultVo login(String username, String password);
}
