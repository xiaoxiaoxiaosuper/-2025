package com.neuedu.yyzxproject.service;

import com.neuedu.yyzxproject.pojo.Nursecontent;
import com.neuedu.yyzxproject.vo.PageInfoVo;
import com.neuedu.yyzxproject.vo.PageResponseVo;

public interface NurseContentService {

    PageResponseVo<Nursecontent> queryAllNurseContentInfo(PageInfoVo pageInfoVo, Nursecontent nursecontent);

    int addNurseContent(Nursecontent nursecontent);

    int updateNurseContent(Nursecontent nursecontent);

    int deleteNurseContent(Nursecontent nursecontent);
}
