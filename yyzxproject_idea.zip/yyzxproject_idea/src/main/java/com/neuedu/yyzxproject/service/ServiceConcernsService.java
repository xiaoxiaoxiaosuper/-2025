package com.neuedu.yyzxproject.service;

import com.neuedu.yyzxproject.pojo.Customer;
import com.neuedu.yyzxproject.pojo.CustomerNurseitem;
import com.neuedu.yyzxproject.pojo.Nursecontent;
import com.neuedu.yyzxproject.pojo.User;
import com.neuedu.yyzxproject.vo.CustomerNursingRecords;
import com.neuedu.yyzxproject.vo.PageInfoVo;
import com.neuedu.yyzxproject.vo.PageResponseVo;
import com.neuedu.yyzxproject.vo.PurchasedNursingServices;

import java.util.Date;

public interface ServiceConcernsService {
    public PageResponseVo<CustomerNursingRecords> queryCustomerInfo(PageInfoVo pageInfoVo, Customer customer);

    public PageResponseVo<PurchasedNursingServices> queryCustomerPurchasedNursingService(PageInfoVo pageInfoVo, Customer customer);

    public int deleteCustomerPurchasedNursingServiceById(Integer nursingServiceId);

    public int renewalNursingService(Integer customerNurseitemId, Integer newQuantity, Date newMaturityTime);

    public PageResponseVo<Nursecontent> queryNursingService(PageInfoVo pageInfoVo, Nursecontent nursecontent);

    public int selectNursingService(CustomerNurseitem customerNurseitem);
}
