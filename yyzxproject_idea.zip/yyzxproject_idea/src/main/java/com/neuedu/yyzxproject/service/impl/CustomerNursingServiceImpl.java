package com.neuedu.yyzxproject.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.neuedu.yyzxproject.mapper.CustomerNursingMapper;
import com.neuedu.yyzxproject.pojo.Customer;
import com.neuedu.yyzxproject.pojo.Nurselevel;
import com.neuedu.yyzxproject.pojo.User;
import com.neuedu.yyzxproject.service.CustomerNursingService;
import com.neuedu.yyzxproject.vo.PageInfoVo;
import com.neuedu.yyzxproject.vo.PageResponseVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerNursingServiceImpl implements CustomerNursingService {
    @Autowired
    private CustomerNursingMapper customerNursingMapper;

    private <T> PageResponseVo<T> getPageResponse(List<T> list) {
        PageInfo<T> pageInfo = new PageInfo<>(list);
        long total = pageInfo.getTotal();
        int pageSize = pageInfo.getPageSize();
        int currentPage = pageInfo.getPageNum();
        int pages = pageInfo.getPages();
        List<T> dataList = pageInfo.getList();

        PageResponseVo<T> pageResponseVo = new PageResponseVo<>();
        pageResponseVo.setData(dataList);
        pageResponseVo.setCurrentPage(currentPage);
        pageResponseVo.setPageSize(pageSize);
        pageResponseVo.setTotal(total);
        pageResponseVo.setPageNum(pages);
        return pageResponseVo;
    }

    @Override
    public PageResponseVo<Customer> queryAllCustomerInfo(PageInfoVo pageInfoVo, Customer customer) {
        PageHelper.startPage(pageInfoVo.getCurrentPage(), pageInfoVo.getPageSize());
        List<Customer> customers = customerNursingMapper.queryAllCustomerInfo(customer);
        return getPageResponse(customers);
    }

    @Override
    public int deleteCustomerNursingLevel(Customer customer) {
        return customerNursingMapper.deleteCustomerNursingLevel(customer);
    }

    @Override
    public int allocationCustomerNursingLevel(Customer customer, Nurselevel nurselevel) {
        return customerNursingMapper.allocationCustomerNursingLevel(customer,nurselevel);
    }
}
