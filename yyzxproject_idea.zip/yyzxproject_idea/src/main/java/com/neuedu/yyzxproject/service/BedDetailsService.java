package com.neuedu.yyzxproject.service;


import com.neuedu.yyzxproject.pojo.BedDetails;
import com.neuedu.yyzxproject.vo.BedDetailsVo;
import com.neuedu.yyzxproject.vo.PageInfoVo;
import com.neuedu.yyzxproject.vo.PageResponseVo;

public interface BedDetailsService {
    public PageResponseVo<BedDetailsVo> queryBedInfo(PageInfoVo pageInfoVo, BedDetailsVo bedDetailsVo);

    int exchangeBedInfo(BedDetails bedDetails);

    int reviseBedInfo(BedDetails bedDetails);
}
