package com.neuedu.yyzxproject.vo;

import lombok.Data;

@Data
public class PageInfoVo {
    private Integer currentPage;
    private Integer pageSize;
}
