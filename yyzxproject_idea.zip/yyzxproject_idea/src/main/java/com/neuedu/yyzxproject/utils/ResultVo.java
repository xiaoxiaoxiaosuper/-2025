package com.neuedu.yyzxproject.utils;

import com.neuedu.yyzxproject.vo.CwsyjlBedVo;
import lombok.Data;

import java.util.List;

/**
 * 返回结果对象
 */
@Data
public class ResultVo<T> {

    private String code;
    private String message;
    private T data;
    private String token;

    /**
     * 成功，但是不添加数据(data)
     */
    public static ResultVo ok(String message) {
        ResultVo resultVo = new ResultVo();
        resultVo.setCode("200");
        resultVo.setMessage(message);
        return resultVo;
    }

    /**
     * 成功，添加数据(data)
     */
    public static <T> ResultVo ok(T data) {
        ResultVo resultVo = new ResultVo();
        resultVo.setCode("200");
        resultVo.setData(data);
        return resultVo;
    }

    /**
     * 成功，添加数据(data)及添加提示消息
     */
    public static <T> ResultVo ok(String message, T data) {
        ResultVo resultVo = new ResultVo();
        resultVo.setCode("200");
        resultVo.setMessage(message);
        resultVo.setData(data);
        return resultVo;
    }
    /**
     * 失败，添加提示信息
     */
    public static ResultVo fail(String message) {
        ResultVo resultVo = new ResultVo();
        resultVo.setCode("400");
        resultVo.setMessage(message);
        return resultVo;
    }

    /**
     * 登陆成功之后，返回对象与token
     */
    public static <T> ResultVo ok(T data,String token){
        ResultVo resultVo = new ResultVo();
        resultVo.setCode("200");
        resultVo.setMessage("操作成功");
        resultVo.setData(data);
        resultVo.setToken(token);
        return resultVo;
    }
}
