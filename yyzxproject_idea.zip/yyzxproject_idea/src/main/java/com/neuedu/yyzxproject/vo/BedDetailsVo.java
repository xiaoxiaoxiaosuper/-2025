package com.neuedu.yyzxproject.vo;

import com.neuedu.yyzxproject.pojo.BedDetails;
import lombok.Data;

@Data
public class BedDetailsVo extends BedDetails {
    private String customerName;
    private String customerSex;
}
