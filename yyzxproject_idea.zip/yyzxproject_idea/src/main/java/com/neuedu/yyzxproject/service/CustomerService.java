package com.neuedu.yyzxproject.service;

import com.neuedu.yyzxproject.pojo.Customer;
import com.neuedu.yyzxproject.vo.FoodManage;
import com.neuedu.yyzxproject.vo.PageInfoVo;
import com.neuedu.yyzxproject.vo.PageResponseVo;

public interface CustomerService {
    public PageResponseVo<Customer> queryAllCustomer(PageInfoVo pageInfoVo,Customer customer);
    public int deleteCustomerById(Integer customerId);
    public int saveCustomer(Customer customer);

    PageResponseVo<FoodManage> queryFoodManage(PageInfoVo pageInfoVo, Customer customer);

    int reviseCustomerInfo(Customer customer);
}
