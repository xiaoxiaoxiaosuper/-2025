package com.neuedu.yyzxproject.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.neuedu.yyzxproject.mapper.BackdownMapper;
import com.neuedu.yyzxproject.pojo.BackDown;
import com.neuedu.yyzxproject.pojo.Customer;
import com.neuedu.yyzxproject.service.BackdownService;
import com.neuedu.yyzxproject.vo.CustomerNursingRecords;
import com.neuedu.yyzxproject.vo.FoodManage;
import com.neuedu.yyzxproject.vo.PageInfoVo;
import com.neuedu.yyzxproject.vo.PageResponseVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BackdownServiceImpl implements BackdownService {
    @Autowired
    private BackdownMapper backdownMapper;
    private <T> PageResponseVo<T> getPageResponse(List<T> list) {
        PageInfo<T> pageInfo = new PageInfo<>(list);
        long total = pageInfo.getTotal();
        int pageSize = pageInfo.getPageSize();
        int currentPage = pageInfo.getPageNum();
        int pages = pageInfo.getPages();
        List<T> dataList = pageInfo.getList();

        PageResponseVo<T> pageResponseVo = new PageResponseVo<>();
        pageResponseVo.setData(dataList);
        pageResponseVo.setCurrentPage(currentPage);
        pageResponseVo.setPageSize(pageSize);
        pageResponseVo.setTotal(total);
        pageResponseVo.setPageNum(pages);
        return pageResponseVo;
    }
    @Override
    public PageResponseVo<BackDown> queryAllBackdownInfo(PageInfoVo pageInfoVo) {
        PageHelper.startPage(pageInfoVo.getCurrentPage(),pageInfoVo.getPageSize());
        List<BackDown> backDowns = backdownMapper.queryAllBackdownInfo();
        return getPageResponse(backDowns);
    }
}
