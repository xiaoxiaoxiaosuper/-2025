package com.neuedu.yyzxproject.vo;

import com.neuedu.yyzxproject.pojo.Room;
import lombok.Data;
import java.util.List;

@Data
public class CwsyBedVo {

    // 房间与床位的列表信息
    private List<Room> roomList;

    // 总床位
    private Integer zcw;

    // 空闲床位
    private Integer kx;

    // 有人的床位
    private Integer yr;

    // 外出的床位
    private Integer cw;
}
