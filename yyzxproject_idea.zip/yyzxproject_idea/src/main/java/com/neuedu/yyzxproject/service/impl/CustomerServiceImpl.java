package com.neuedu.yyzxproject.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.neuedu.yyzxproject.mapper.CustomerMapper;
import com.neuedu.yyzxproject.pojo.Customer;
import com.neuedu.yyzxproject.service.CustomerService;
import com.neuedu.yyzxproject.vo.CustomerNursingRecords;
import com.neuedu.yyzxproject.vo.FoodManage;
import com.neuedu.yyzxproject.vo.PageInfoVo;
import com.neuedu.yyzxproject.vo.PageResponseVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerServiceImpl implements CustomerService {
    @Autowired
    private CustomerMapper customerMapper;

    private <T> PageResponseVo<T> getPageResponse(List<T> list) {
        PageInfo<T> pageInfo = new PageInfo<>(list);
        long total = pageInfo.getTotal();
        int pageSize = pageInfo.getPageSize();
        int currentPage = pageInfo.getPageNum();
        int pages = pageInfo.getPages();
        List<T> dataList = pageInfo.getList();

        PageResponseVo<T> pageResponseVo = new PageResponseVo<>();
        pageResponseVo.setData(dataList);
        pageResponseVo.setCurrentPage(currentPage);
        pageResponseVo.setPageSize(pageSize);
        pageResponseVo.setTotal(total);
        pageResponseVo.setPageNum(pages);
        return pageResponseVo;
    }

    @Override
    public PageResponseVo<Customer> queryAllCustomer(PageInfoVo pageInfoVo,Customer customer){
        PageHelper.startPage(pageInfoVo.getCurrentPage(),pageInfoVo.getPageSize());
        List<Customer> customers = customerMapper.queryAllCustomer(customer);
        return getPageResponse(customers);
    }
    @Override
    public int deleteCustomerById(Integer customerId){
        customerMapper.updateBedStatus(customerMapper.getBedIdByCustomerId(customerId));
        int num = customerMapper.deleteCustomerById(customerId);
        return num;
    }

    @Override
    public int saveCustomer(Customer customer) {
        int bedId = customer.getBedId();
        customerMapper.modifyBedStatus(bedId);
        return customerMapper.saveCustomer(customer);
    }

    @Override
    public PageResponseVo<FoodManage> queryFoodManage(PageInfoVo pageInfoVo, Customer customer) {
        PageHelper.startPage(pageInfoVo.getCurrentPage(), pageInfoVo.getPageSize());
        List<FoodManage> customers = customerMapper.queryFoodManage(customer);
        return getPageResponse(customers);
    }

    @Override
    public int reviseCustomerInfo(Customer customer) {
        return customerMapper.reviseCustomerInfo(customer);
    }
}
