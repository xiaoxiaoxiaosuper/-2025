package com.neuedu.yyzxproject.vo;

import com.neuedu.yyzxproject.pojo.CustomerPreference;
import lombok.Data;

@Data
public class FoodManage extends CustomerPreference{
    private String customerName;
    private Integer customerAge;
    private Integer customerSex;
}
