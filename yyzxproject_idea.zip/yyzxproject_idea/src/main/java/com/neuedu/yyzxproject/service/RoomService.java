package com.neuedu.yyzxproject.service;

import com.neuedu.yyzxproject.utils.ResultVo;
import com.neuedu.yyzxproject.vo.CwsyBedVo;
public interface RoomService {
    public ResultVo<CwsyBedVo> findCwsyBedVo(String floor);
}