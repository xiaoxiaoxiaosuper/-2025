package com.neuedu.yyzxproject.service.impl;

import com.neuedu.yyzxproject.mapper.BedMapper;
import com.neuedu.yyzxproject.pojo.Bed;
import com.neuedu.yyzxproject.service.BedService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BedServiceImpl implements BedService {
    @Autowired
    private BedMapper bedMapper;
    @Override
    public List<Bed> queryKxcwByRoomNo(String roomNo) {
        return bedMapper.queryKxcwByRoomNo(roomNo);
    }
}