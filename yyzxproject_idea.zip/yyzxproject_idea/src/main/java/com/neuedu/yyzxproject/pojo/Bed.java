package com.neuedu.yyzxproject.pojo;

import lombok.Data;

@Data
public class Bed {
    private Integer id;
    private Integer roomNo;
    private Integer bedStatus;
    private String remarks;
    private String bedNo;
}
