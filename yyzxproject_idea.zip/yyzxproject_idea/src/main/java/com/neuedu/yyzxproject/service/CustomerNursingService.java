package com.neuedu.yyzxproject.service;

import com.neuedu.yyzxproject.pojo.Customer;
import com.neuedu.yyzxproject.pojo.Nurselevel;
import com.neuedu.yyzxproject.vo.PageInfoVo;
import com.neuedu.yyzxproject.vo.PageResponseVo;

public interface CustomerNursingService {
    PageResponseVo<Customer> queryAllCustomerInfo(PageInfoVo pageInfoVo, Customer customer);

    int deleteCustomerNursingLevel(Customer customer);

    int allocationCustomerNursingLevel(Customer customer, Nurselevel nurselevel);
}
