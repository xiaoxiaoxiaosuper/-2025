package com.neuedu.yyzxproject.service;

import com.neuedu.yyzxproject.pojo.Nursecontent;
import com.neuedu.yyzxproject.pojo.Nurselevel;
import com.neuedu.yyzxproject.vo.PageInfoVo;
import com.neuedu.yyzxproject.vo.PageResponseVo;
import org.springframework.web.bind.annotation.RequestParam;

public interface NurseLevelService {
    PageResponseVo<Nurselevel> findNurselevel(PageInfoVo pageInfoVo);

    int addNurselevel(Nurselevel nurselevel);

    int modifyNurselevelStatus(Nurselevel nurselevel);

    PageResponseVo<Nursecontent> queryNursingProject(PageInfoVo pageInfoVo,Nursecontent nursecontent);

    PageResponseVo<Nursecontent> queryNursingProjectByLevel(PageInfoVo pageInfoVo, Nurselevel nurselevel);

    int deleteProjectInLevel(Integer levelId, Integer itemId);
}
