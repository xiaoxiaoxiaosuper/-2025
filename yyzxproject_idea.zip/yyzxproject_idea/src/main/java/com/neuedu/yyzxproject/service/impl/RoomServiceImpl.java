package com.neuedu.yyzxproject.service.impl;

import com.neuedu.yyzxproject.mapper.RoomMapper;
import com.neuedu.yyzxproject.pojo.Bed;
import com.neuedu.yyzxproject.pojo.Room;
import com.neuedu.yyzxproject.service.RoomService;
import com.neuedu.yyzxproject.utils.ResultVo;
import com.neuedu.yyzxproject.vo.CwsyBedVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class RoomServiceImpl implements RoomService {

    @Autowired
    private RoomMapper roomMapper;

    @Override
    public ResultVo<CwsyBedVo> findCwsyBedVo(String floor) {
        // 返回的结果集
        CwsyBedVo cbv = new CwsyBedVo();

        // 定义数量
        int zcw = 0;
        int kx = 0;
        int yr = 0;
        int cw = 0;

        // 获取到楼层对应的房间信息
        List<Room> rooms = roomMapper.queryRoomsByFloor(floor);

        // 获取每个房间对应的床位信息
        for (Room room : rooms) {
            // 通过房间号查询床位信息
            List<Bed> beds = roomMapper.queryBedsByRoomNo(room.getRoomNo() + "");

            for (Bed bed : beds) {
                zcw++;
                if (bed.getBedStatus() == 1) {
                    kx++;
                }
                if (bed.getBedStatus() == 2) {
                    yr++;
                }
                if (bed.getBedStatus() == 3) {
                    cw++;
                }
            }

            room.setBedList(beds);
        }

        // 设置返回的床位示意图的内容
        cbv.setRoomList(rooms);
        cbv.setZcw(zcw);
        cbv.setKx(kx);
        cbv.setYr(yr);
        cbv.setCw(cw);

        return ResultVo.ok(cbv);
    }
}
