package com.neuedu.yyzxproject.vo;

import lombok.Data;

import java.util.List;
@Data
public class PageResponseVo<T> {
    private int currentPage;
    private int pageSize;
    private int pageNum;
    private Long total;
    private List<T> data;
}
