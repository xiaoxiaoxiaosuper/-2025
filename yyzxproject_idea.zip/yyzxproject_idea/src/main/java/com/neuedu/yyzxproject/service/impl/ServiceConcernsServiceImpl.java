package com.neuedu.yyzxproject.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.neuedu.yyzxproject.mapper.ServiceConcernsMapper;
import com.neuedu.yyzxproject.pojo.Customer;
import com.neuedu.yyzxproject.pojo.CustomerNurseitem;
import com.neuedu.yyzxproject.pojo.Nursecontent;
import com.neuedu.yyzxproject.pojo.User;
import com.neuedu.yyzxproject.service.ServiceConcernsService;
import com.neuedu.yyzxproject.vo.CustomerNursingRecords;
import com.neuedu.yyzxproject.vo.PageInfoVo;
import com.neuedu.yyzxproject.vo.PageResponseVo;
import com.neuedu.yyzxproject.vo.PurchasedNursingServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class ServiceConcernsServiceImpl implements ServiceConcernsService {
    @Autowired
    private ServiceConcernsMapper serviceConcernsMapper;
    @Override
    public PageResponseVo<CustomerNursingRecords> queryCustomerInfo(PageInfoVo pageInfoVo, Customer customer){
        PageHelper.startPage(pageInfoVo.getCurrentPage(), pageInfoVo.getPageSize());
        List<CustomerNursingRecords> customers = serviceConcernsMapper.queryCustomerInfo(customer);
        return getPageResponse(customers);
    }

    @Override
    public PageResponseVo<PurchasedNursingServices> queryCustomerPurchasedNursingService(PageInfoVo pageInfoVo, Customer customer) {
        PageHelper.startPage(pageInfoVo.getCurrentPage(), pageInfoVo.getPageSize());
        List<PurchasedNursingServices> purchasedNursingServices = serviceConcernsMapper.queryCustomerPurchasedNursingService(customer);
        return getPageResponse(purchasedNursingServices);
    }

    @Override
    public int deleteCustomerPurchasedNursingServiceById(Integer nursingServiceId) {
        int num = serviceConcernsMapper.deleteCustomerPurchasedNursingService(nursingServiceId);
        return num;
    }

    @Override
    public int renewalNursingService(Integer customerNurseitemId, Integer newQuantity, Date newMaturityTime) {
        int num = serviceConcernsMapper.renewalNursingService(customerNurseitemId,newQuantity,newMaturityTime);
        return num;
    }

    @Override
    public PageResponseVo<Nursecontent> queryNursingService(PageInfoVo pageInfoVo, Nursecontent nursecontent) {
        PageHelper.startPage(pageInfoVo.getCurrentPage(),pageInfoVo.getPageSize());
        List<Nursecontent> nursecontents = serviceConcernsMapper.queryNursingService(nursecontent);
        return getPageResponse(nursecontents);
    }

    @Override
    public int selectNursingService(CustomerNurseitem customerNurseitem) {
        return serviceConcernsMapper.selectNursingService(customerNurseitem);
    }


    private <T> PageResponseVo<T> getPageResponse(List<T> list) {
        PageInfo<T> pageInfo = new PageInfo<>(list);
        long total = pageInfo.getTotal();
        int pageSize = pageInfo.getPageSize();
        int currentPage = pageInfo.getPageNum();
        int pages = pageInfo.getPages();
        List<T> dataList = pageInfo.getList();

        PageResponseVo<T> pageResponseVo = new PageResponseVo<>();
        pageResponseVo.setData(dataList);
        pageResponseVo.setCurrentPage(currentPage);
        pageResponseVo.setPageSize(pageSize);
        pageResponseVo.setTotal(total);
        pageResponseVo.setPageNum(pages);
        return pageResponseVo;
    }
}
