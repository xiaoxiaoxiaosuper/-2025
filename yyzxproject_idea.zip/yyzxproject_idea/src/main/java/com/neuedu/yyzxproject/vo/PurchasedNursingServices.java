package com.neuedu.yyzxproject.vo;

import com.neuedu.yyzxproject.pojo.CustomerNurseitem;
import lombok.Data;

@Data
public class PurchasedNursingServices extends CustomerNurseitem {
    private String customerName;
    private String nursingName;
    private String servicePrice;

    //-:药物余量状态 0数量正常，1即将用完，2已欠费
    private Integer nurseNumberStatus;
    //-:服务期限状态 0未到期，1已到期
    private Integer maturityTimeStatus;
}
