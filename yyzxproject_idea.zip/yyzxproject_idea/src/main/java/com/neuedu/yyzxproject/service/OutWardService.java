package com.neuedu.yyzxproject.service;

import com.neuedu.yyzxproject.pojo.BackDown;
import com.neuedu.yyzxproject.pojo.OutWard;
import com.neuedu.yyzxproject.vo.PageInfoVo;
import com.neuedu.yyzxproject.vo.PageResponseVo;

public interface OutWardService {
    PageResponseVo<OutWard> queryAllOutwardInfo(PageInfoVo pageInfoVo);

    int approval(OutWard outWard);
}
