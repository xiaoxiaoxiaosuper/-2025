package com.neuedu.yyzxproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YyzxprojectApplicationTests {

    @Test
    void contextLoads() {
    }

}
